$(function () {
    $('.car-big').hover(function(){
        $('.car-show').animate({opacity:1},800);
    },function () {
        $('.car-show').animate({opacity:0},500);
    })
})